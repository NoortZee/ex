# Добавление bootstrap

Распоковываем архив `bootstrap.zip`

Перемещаем файлы:

- `bootstrap/dist/bootstrap.min.css` -> `public/css/bootstrap.min.css`
- `bootstrap.bundle.js` -> `public/js/bootstrap.bundle.js`
